Project 2A

What we implemented:

We implemented the load function in SqlEngine.cc as specified by the spec. It takes a file and loads the tuples into our database

Files modified:
	SqlEngine.cc - we modified the load function

How we split the work:

We both implemented the load function on our own so we can get a better understanding of bruinbase. 

How we can improve as a team:

We could work more on PRoject 2B since it is supposed to be more time consuming