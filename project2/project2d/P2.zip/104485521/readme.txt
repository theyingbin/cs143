Project 2D

We are turning this project in 2 days late. We would like to use two grace days on this please. Thanks!

What we implemented:

We implemented the functions in SqlEngine.cc and modified previous files so that our code works as expected

Files modified:
	BTreeNode.cc - we fixed our implementation for some of the functions. Insert and split has a good amount of modifications
	BTreeNode.h - modified as the implementation needed
	SqlEngine.cc - we implemented the load and select functions
	BTreeIndex.cc - we fixed our implementation for some of the functions. Insert has a good amount of modifications
	BTreeIndex.h - modified as the implementation needed

How we split the work:

Connor did the load function and the setup for the select function. Ying implemented the part of the select function where we choose which tuples to output. We collaborated using github by constantly pushing and pulling each others changes and communicated using using Messanger

How we can improve as a team:

We could have started debugging a little earlier.

Emails:
Ying Bin Wu - yingbinwu@ucla.edu
Connor Kenny - ckenny9739@ucla.edu