Project 2C

What we implemented:

We implemented the functions in BTreeIndex.cc

Files modified:
	BTreeIndex.cc - we implemented all the required functions
	BTreeIndex.h - we added a constructor for the class

How we split the work:

We implemented all of the functions together by pair programming. 

How we can improve as a team:

We could start on Project 2D a little earlier since it took some time to wrap our heads around Project 2C

Emails:
Ying Bin Wu - yingbinwu@ucla.edu
Connor Kenny - ckenny9739@ucla.edu