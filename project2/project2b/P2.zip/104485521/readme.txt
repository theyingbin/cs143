Project 2B

What we implemented:

We implemented the functions in BTreeNode.cc

Files modified:
	BTreeNode.cc - we implemented all the required functions
	BTreeNode.h - we added a constructor for the class

How we split the work:

We implemented all of the functions together by pair programming. 

How we can improve as a team:

We could start on Project 2C a little earlier since it took some time to wrap our heads around Project 2B

Emails:
Ying Bin Wu - yingbinwu@ucla.edu
Connor Kenny - ckenny9739@ucla.edu