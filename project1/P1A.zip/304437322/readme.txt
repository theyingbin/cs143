CS 143 Project 1A

Done Together: Together, we figured out the regular expressions needed for this project as well as put together a majority of the layout of the website. We spent most of the time on this project in pair programming, but some smaller things were done separately.

Done by Connor Kenny: Came up with some tweaks to the regex and checked piazza for weird test cases. Then found solutions to these test cases so that our project would match the demo. Also did everything necessary to turn in the project.

Done by Ying Bin Wu: Took over the coding portion of the project during pair programming and continued to beautify the code on his own. Also made sure the calculator was implemented correctly and did preliminary testing before sending it over to Connor for a final check.


